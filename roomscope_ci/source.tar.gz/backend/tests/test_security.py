import base64
import importlib.util
import json
import os
import pathlib
import unittest
from unittest.mock import patch

# Test clients never discover or use credentials from the host or metadata service.
os.environ.update(AWS_EC2_METADATA_DISABLED='true', AWS_ACCESS_KEY_ID='test-only',
                  AWS_SECRET_ACCESS_KEY='test-only', AWS_DEFAULT_REGION='eu-west-2',
                  TABLE_NAME='test-captures', BUCKET_NAME='test-captures')
spec = importlib.util.spec_from_file_location('backend_app', pathlib.Path(__file__).parents[1]/'app.py')
app = importlib.util.module_from_spec(spec)
spec.loader.exec_module(app)

USER = '64996a5b-f30a-4ffb-8a21-f7e6cb2b36a3'
OTHER = '6f0f8e67-d3c8-4695-aef4-720b9706447d'
SCAN = '453a1361-0686-4abf-bae6-e9732be9d7ea'
SHA = base64.b64encode(bytes(range(32))).decode()


def files():
    return [{'name': name, 'size': 100, 'sha256': SHA} for name in app.FILES]


def event(route, body=None, user=USER, token_use='access'):
    return {'routeKey': route, 'body': json.dumps(body or {}),
            'pathParameters': {'id': SCAN}, 'requestContext': {'authorizer': {'jwt': {'claims': {
                'sub': user, 'token_use': token_use, 'scope': 'openid roomscope/sync'}}}}}


class Table:
    def __init__(self): self.items = {}
    def get_item(self, Key, **kwargs): return {'Item': self.items[tuple(Key.values())]} if tuple(Key.values()) in self.items else {}
    def put_item(self, Item, **kwargs): self.items[(Item['pk'],Item['sk'])] = Item.copy()
    def update_item(self, Key, **kwargs): self.items[tuple(Key.values())]['status'] = 'complete'


class Storage:
    def __init__(self): self.calls = []; self.corrupt = False
    def generate_presigned_post(self, bucket, key, **kwargs):
        self.calls.append((bucket,key,kwargs))
        return {'url': 'https://test-captures.s3.eu-west-2.amazonaws.com/', 'fields': kwargs['Fields']}
    def head_object(self, **kwargs):
        return {'ContentLength': 100, 'ServerSideEncryption': 'AES256',
                'ChecksumSHA256': 'wrong' if self.corrupt else SHA}


class SecurityTests(unittest.TestCase):
    def setUp(self):
        self.table, self.storage = Table(), Storage()
        self.table_patch = patch.object(app, 'TABLE', self.table)
        self.s3_patch = patch.object(app, 'S3', self.storage)
        self.table_patch.start(); self.s3_patch.start()
    def tearDown(self): self.table_patch.stop(); self.s3_patch.stop()
    def request(self, data=None):
        return app.handler(event('POST /scans', data or {'scanId': SCAN,'files':files()}), None)
    def test_no_jwt_cannot_upload(self):
        self.assertEqual(app.handler({'routeKey':'POST /scans'},None)['statusCode'],401)
        self.assertEqual(self.storage.calls,[])
    def test_id_token_cannot_replace_scoped_access_token(self):
        self.assertEqual(app.handler(event('POST /scans',token_use='id'),None)['statusCode'],401)
    def test_missing_scope_rejected(self):
        request=event('POST /scans'); request['requestContext']['authorizer']['jwt']['claims']['scope']='openid'
        self.assertEqual(app.handler(request,None)['statusCode'],401)
    def test_owner_is_derived_from_authenticated_subject(self):
        self.assertEqual(self.request({'scanId':SCAN,'files':files(),'userId':OTHER})['statusCode'],200)
        self.assertTrue(all(f'users/{USER}/' in call[1] for call in self.storage.calls))
    def test_other_user_cannot_complete_owner_capture(self):
        self.request()
        self.assertEqual(app.handler(event('POST /scans/{id}/complete',user=OTHER),None)['statusCode'],404)
    def test_exact_size_checksum_encryption_and_expiry_are_signed(self):
        self.request()
        for _,_,options in self.storage.calls:
            self.assertEqual(options['ExpiresIn'],300)
            self.assertIn(['content-length-range',100,100],options['Conditions'])
            self.assertIn({'x-amz-checksum-sha256':SHA},options['Conditions'])
            self.assertIn({'x-amz-server-side-encryption':'AES256'},options['Conditions'])
    def test_path_traversal_and_oversized_files_rejected(self):
        bad=files(); bad[0]['name']='../../capture.mp4'
        self.assertEqual(self.request({'scanId':SCAN,'files':bad})['statusCode'],400)
        bad=files(); bad[0]['size']=app.MAX_BYTES+1
        self.assertEqual(self.request({'scanId':SCAN,'files':bad})['statusCode'],400)
    def test_bad_checksum_rejected(self):
        bad=files(); bad[0]['sha256']='not-a-checksum'
        self.assertEqual(self.request({'scanId':SCAN,'files':bad})['statusCode'],400)
    def test_content_change_cannot_reuse_scan_id(self):
        self.request(); changed=files(); changed[0]['size']=101
        self.assertEqual(self.request({'scanId':SCAN,'files':changed})['statusCode'],409)
    def test_integrity_failure_never_marks_complete(self):
        self.request(); self.storage.corrupt=True
        self.assertEqual(app.handler(event('POST /scans/{id}/complete'),None)['statusCode'],409)
        self.assertEqual(next(iter(self.table.items.values()))['status'],'uploading')
    def test_verified_upload_and_retry_are_idempotent(self):
        self.request()
        self.assertEqual(app.handler(event('POST /scans/{id}/complete'),None)['statusCode'],200)
        self.storage.calls.clear()
        self.assertTrue(json.loads(self.request()['body'])['complete'])
        self.assertEqual(self.storage.calls,[])


if __name__ == '__main__': unittest.main(verbosity=2)
