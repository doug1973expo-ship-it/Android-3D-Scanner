"""Authenticated, per-user, bounded S3 uploads. No AWS credentials in the app."""
import base64
import json
import logging
import os
import re
import time
import uuid
from decimal import Decimal

import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

S3 = boto3.client('s3')
TABLE = boto3.resource('dynamodb').Table(os.environ['TABLE_NAME'])
BUCKET = os.environ['BUCKET_NAME']
MAX_BYTES = 256 * 1024 * 1024
FILES = {'capture.mp4': 'video/mp4', 'points.ply': 'application/octet-stream',
         'trajectory.jsonl': 'application/x-ndjson', 'manifest.json': 'application/json'}


class RequestError(Exception):
    def __init__(self, message, status=400):
        self.status = status
        super().__init__(message)


def response(status, data):
    return {'statusCode': status,
            'headers': {'content-type': 'application/json', 'cache-control': 'no-store'},
            'body': json.dumps(data, default=lambda x: int(x) if isinstance(x, Decimal) else str(x))}


def user_id(event):
    claims = event.get('requestContext', {}).get('authorizer', {}).get('jwt', {}).get('claims', {})
    subject = claims.get('sub', '')
    scopes = set(claims.get('scope', '').split())
    if claims.get('token_use') != 'access' or 'roomscope/sync' not in scopes:
        raise RequestError('Sign in is required.', 401)
    try:
        return str(uuid.UUID(subject))
    except (ValueError, TypeError, AttributeError):
        raise RequestError('Invalid identity.', 401)


def scan_id(value):
    try:
        return str(uuid.UUID(value))
    except (ValueError, TypeError, AttributeError):
        raise RequestError('Invalid scan ID.')


def parse_manifest(data):
    files = data.get('files')
    if not isinstance(files, list) or len(files) != len(FILES):
        raise RequestError('Exactly four capture files are required.')
    result = []
    seen = set()
    for item in files:
        if not isinstance(item, dict):
            raise RequestError('Invalid file descriptor.')
        name, size = item.get('name'), item.get('size')
        checksum = item.get('sha256', '')
        if name not in FILES or name in seen:
            raise RequestError('Unexpected or duplicate file.')
        if type(size) is not int or not 0 < size <= MAX_BYTES:
            raise RequestError('A file exceeds the 256 MiB limit or is empty.')
        try:
            raw = base64.b64decode(checksum, validate=True)
        except (ValueError, TypeError):
            raise RequestError('Invalid SHA-256 checksum.')
        if len(raw) != 32 or base64.b64encode(raw).decode() != checksum:
            raise RequestError('Invalid SHA-256 checksum.')
        seen.add(name)
        result.append({'name': name, 'size': size, 'sha256': checksum})
    return sorted(result, key=lambda item: item['name'])


def item_key(subject, identifier):
    return {'pk': f'USER#{subject}', 'sk': f'SCAN#{identifier}'}


def create_upload(subject, data):
    identifier = scan_id(data.get('scanId'))
    files = parse_manifest(data)
    key = item_key(subject, identifier)
    item = TABLE.get_item(Key=key, ConsistentRead=True).get('Item')
    if item is not None:
        if item['files'] != files:
            raise RequestError('This scan ID already has different contents.', 409)
        if item['status'] == 'complete':
            return {'scanId': identifier, 'complete': True}
    else:
        try:
            TABLE.put_item(Item={**key, 'scanId': identifier, 'files': files,
                                 'status': 'uploading', 'createdAt': int(time.time())},
                           ConditionExpression='attribute_not_exists(pk)')
        except ClientError as error:
            if error.response['Error']['Code'] == 'ConditionalCheckFailedException':
                raise RequestError('Upload changed concurrently. Retry.', 409)
            raise
    uploads = []
    for file in files:
        object_key = f'users/{subject}/{identifier}/{file["name"]}'
        fields = {'Content-Type': FILES[file['name']],
                  'x-amz-server-side-encryption': 'AES256',
                  'x-amz-checksum-algorithm': 'SHA256',
                  'x-amz-checksum-sha256': file['sha256']}
        conditions = [{name: value} for name, value in fields.items()]
        conditions.append(['content-length-range', file['size'], file['size']])
        signed = S3.generate_presigned_post(BUCKET, object_key, Fields=fields,
                                             Conditions=conditions, ExpiresIn=300)
        uploads.append({'name': file['name'], **signed})
    return {'scanId': identifier, 'complete': False, 'uploads': uploads}


def complete_upload(subject, identifier):
    identifier = scan_id(identifier)
    key = item_key(subject, identifier)
    item = TABLE.get_item(Key=key, ConsistentRead=True).get('Item')
    if item is None:
        raise RequestError('Scan not found.', 404)
    for file in item['files']:
        try:
            head = S3.head_object(Bucket=BUCKET,
                Key=f'users/{subject}/{identifier}/{file["name"]}', ChecksumMode='ENABLED')
        except ClientError as error:
            if error.response['Error']['Code'] in ('404', 'NoSuchKey', 'NotFound'):
                raise RequestError('Upload is incomplete.', 409)
            raise
        if (head['ContentLength'] != file['size'] or
                head.get('ChecksumSHA256') != file['sha256'] or
                head.get('ServerSideEncryption') != 'AES256'):
            raise RequestError('Uploaded file failed integrity verification.', 409)
    TABLE.update_item(Key=key, UpdateExpression='SET #s = :s, completedAt = :t',
                      ExpressionAttributeNames={'#s': 'status'},
                      ExpressionAttributeValues={':s': 'complete', ':t': int(time.time())})
    return {'scanId': identifier, 'complete': True}


def handler(event, context):
    try:
        subject = user_id(event)
        route = event.get('routeKey')
        if route == 'POST /scans':
            raw = event.get('body') or '{}'
            if event.get('isBase64Encoded'):
                raw = base64.b64decode(raw, validate=True).decode()
            if len(raw) > 8192:
                raise RequestError('Request too large.', 413)
            data = json.loads(raw)
            if not isinstance(data, dict):
                raise RequestError('Expected a JSON object.')
            return response(200, create_upload(subject, data))
        if route == 'POST /scans/{id}/complete':
            return response(200, complete_upload(subject, event.get('pathParameters', {}).get('id')))
        if route == 'GET /scans':
            items = TABLE.query(KeyConditionExpression=Key('pk').eq(f'USER#{subject}'),
                                Limit=100, ScanIndexForward=False).get('Items', [])
            return response(200, {'scans': [{'scanId': item['scanId'],
                'status': item['status'], 'createdAt': item['createdAt']} for item in items]})
        raise RequestError('Route not found.', 404)
    except RequestError as error:
        return response(error.status, {'error': str(error)})
    except (json.JSONDecodeError, UnicodeDecodeError, ValueError):
        return response(400, {'error': 'Malformed request.'})
    except Exception:
        logging.exception('Capture request failed')
        return response(500, {'error': 'The request could not be completed. Retry later.'})
